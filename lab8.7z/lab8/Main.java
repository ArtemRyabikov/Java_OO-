package com.company.lab8;

public class Main {
}
