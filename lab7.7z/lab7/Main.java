package com.company.lab7;

public class Main {
}
