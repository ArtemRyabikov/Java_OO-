package com.company.lab7;

public interface IntProc {
    boolean accept (int a);
}
