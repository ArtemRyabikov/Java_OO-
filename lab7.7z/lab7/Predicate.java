package com.company.lab7;

public interface Predicate {
    boolean accept(double a);
}

